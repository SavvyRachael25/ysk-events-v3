# Announcement posts for YSK Events
September 21, 2026. PSA published today; these go out from YSK's accounts as soon as Shabana approves. Image for all of them: the Seattle court hero from the site (www.yskevents.com), or the LA28 mark on white for the square. Never put text over the LA28 mark. Link everywhere: www.yskevents.com/press

## Instagram (feed)
It's official. The last road to the Olympics runs through Washington.

The Squash Final Qualifier comes to Seattle and Bellevue, June 6 to 10, 2028. Twenty-four men and twenty-four women, two draws, and the winner of each goes to Los Angeles for squash's first Olympic tournament.

Early rounds at PRO Club in Bellevue. Finals on an all-glass court in Seattle.

We've hosted the world here twice before. This time the world is coming to qualify.

Presented by YSK Events. Sign up to hear about the venue and tickets first, link in bio.

#RoadToLA #LA28 #Squash #Seattle #Bellevue #Washington #OlympicSquash #PSAWorldTour #YSKEvents

## Instagram (story, three frames)
1. "It's official." over the court image.
2. "Seattle and Bellevue. June 6 to 10, 2028. The last chance to qualify for LA28." on evergreen.
3. "Hear it first. Venue and tickets." with the link sticker to www.yskevents.com.

## LinkedIn (Shabana's account, and YSK's page)
Today the Professional Squash Association, World Squash and US Squash announced that the Squash Final Qualifier for the Los Angeles 2028 Olympic Games will be held in Seattle and Bellevue, Washington, June 6 to 10, 2028, presented by YSK Events.

Forty-eight players, two draws, two places. The winners go to LA28, where squash makes its Olympic debut.

My family brought this game from Pakistan to Seattle. In 2015 we hosted the first Men's World Championship on U.S. soil. In 2024 the PSA World Tour Finals came to Bellevue. And in 2028, the last road to the Olympics runs through Washington.

This is about far more than a sporting event. It is a chance to welcome the world to our region, and to put a racket in the hands of kids who have never held one.

If your company wants to be part of it, the sponsorship page is live: www.yskevents.com/sponsors

Full release and facts: www.yskevents.com/press

## Facebook
It's official: the Squash Final Qualifier for the LA28 Olympic Games is coming to Seattle and Bellevue, June 6 to 10, 2028.

24 men and 24 women. Two draws. The winner of each qualifies for squash's first Olympic tournament.

Early rounds at PRO Club in Bellevue, finals on an all-glass court in Seattle. Venue and tickets to be announced. Sign up at www.yskevents.com to hear first.

Presented by YSK Events, a Bellevue nonprofit. The world has played here before. Now it comes to qualify.

## X / Threads
The last road to the Olympics runs through Washington. Squash Final Qualifier: Seattle and Bellevue, June 6 to 10, 2028. Two draws, two places at LA28. Presented by YSK Events. www.yskevents.com/press

## Reply to the PSA post (comment from YSK's account)
Honored to host. See you in Washington, June 2028.

## Do not
- Do not call it "the Olympic Qualifier" as if YSK owns the Olympic name; "Squash Final Qualifier for the LA28 Olympic Games" is PSA's wording.
- Do not name a Seattle venue. It has not been announced.
- Do not use the Olympic rings anywhere except inside the cleared LA28 mark.
- Do not tag LA28 or the IOC as partners. Tag @psaworldtour, @worldsquash, @ussquash.
